JABBA THE HUTT

MODELLED BY MATT CLARK 1999

matt@clarky85.freeserve.co.uk


Ok, here it is, my Jabba the Hutt model. After seeing the CG Jabba in
Episode One Special edition I thought I'd have a go myself, and this is
my attempt.  I have to say I found the episode 1 Jabba to be a little
dissapointing - too comical.
I wanted to build a Jabba that resembled the one in Return of the Jedi
and I think the likeness isn't too bad.
Have to say I saw Phantom Menace recently, and I was much more pleased
with the new cg Jabba.  After struggling with this one I have nothing
but respect for the guys at ILM for that beauty!

Feel free to use the mesh as you wish, but keep this file with it (I'd
like some credit!) 

I'd very much like to him animated if anyones up to it!

Comments welcome.

Matt
